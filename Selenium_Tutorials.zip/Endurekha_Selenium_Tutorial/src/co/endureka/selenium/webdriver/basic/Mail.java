package co.endureka.selenium.webdriver.basic;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import library.Utility;
public class Mail {
	WebDriver driver;
	@Test
	public void invokBrowser() throws IOException, InterruptedException {
			System.setProperty("webdriver.chrome.driver", "D:\\Avekshaa\\Rahul_Desale\\Automation\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.get("http://gmail.com/");
			//Utility.captureScreenshot(driver, "Wiki");
			login();
			}
	public void login() throws InterruptedException{
		WebElement link;
		//link = driver.findElement(By.xpath("//ul[@class='h-c-header__cta-list header__nav--ltr']//a[contains(@class,'h-c-header__nav-li-link')][contains(text(),'Sign in')]"));
		//link.click();
		link = driver.findElement(By.id("identifierId"));
		link.sendKeys("rahulperformancetest@gmail.com");
		Thread.sleep(3000);
		link = driver.findElement(By.xpath("//span[@class='RveJvd snByac']"));
		link.click();
		Thread.sleep(3000);
		link = driver.findElement(By.xpath("//input[@name='password']"));
		link.sendKeys("9029749973");
		link = driver.findElement(By.xpath("//span[contains(text(),'Next')]"));
		link.click();
		Thread.sleep(9000);
		driver.quit();
		} 
	public static void main(String[] args) throws IOException, InterruptedException {
		Mail myObj = new Mail();
		myObj.invokBrowser();
	}

}
