package co.endureka.selenium.webdriver.basic;

import java.io.IOException;

import library.ExcelDataConfig;

public class ReadExcelData {

	public static void main(String[] args) throws IOException {
		ExcelDataConfig excel = new ExcelDataConfig("D:\\Avekshaa\\Rahul_Desale\\Automation\\TestData.xlsx");
		System.out.println(excel.getData(0, 2, 1));
	}

}
