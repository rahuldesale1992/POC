package co.endureka.selenium.webdriver.basic;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import library.ExcelDataConfig;
import library.Utility;
public class Day1 {
	WebDriver driver;
	JavascriptExecutor jse;	
	@Test
	public void invokBrowser() throws IOException {
			System.setProperty("webdriver.chrome.driver", "D:\\Avekshaa\\Rahul_Desale\\Automation\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			driver.get("https://www.wikipedia.org/");
			Utility.captureScreenshot(driver, "Wiki");
			login();
			}
	public void login() throws IOException{
		WebElement link;
		link = driver.findElement(By.id("searchInput"));
		ExcelDataConfig excel = new ExcelDataConfig("D:\\Avekshaa\\Rahul_Desale\\Automation\\TestData.xlsx");
		System.out.println(excel.getData(0, 2, 1));
		link.sendKeys("Java");
		link.submit();
			try {
				Thread.sleep(3000);
				Utility.captureScreenshot(driver, "Java");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			driver.quit();
		} 
	public static void main(String[] args) throws IOException {
		Day1 myObj = new Day1();
		myObj.invokBrowser();
	}
}
