package co.endureka.selenium.webdriver.basic;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class ReadExcel2 {
	public static void main(String[] args) throws IOException {
		File scr = new File("D:\\Avekshaa\\Rahul_Desale\\Automation\\TestData.xlsx");
		FileInputStream fis = new FileInputStream(scr);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet1=wb.getSheetAt(0);
		int rowcount=sheet1.getLastRowNum();
		rowcount=rowcount+1;
		System.out.println("Toatal Rows is "+rowcount);
		for (int i=0;i<rowcount;i++) {
		String data0=sheet1.getRow(i).getCell(0).getStringCellValue();
		System.out.println("Data From Row"+i+" is "+data0);
		}
		wb.close();	
	}
}
