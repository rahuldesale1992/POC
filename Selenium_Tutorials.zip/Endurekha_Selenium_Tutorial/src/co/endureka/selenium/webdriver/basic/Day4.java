package co.endureka.selenium.webdriver.basic;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import library.Utility;
public class Day4 {
	WebDriver driver;
	JavascriptExecutor jse;	
	@Test
	public void invokBrowser() throws IOException {
			System.setProperty("webdriver.chrome.driver", "D:\\Avekshaa\\Rahul_Desale\\Automation\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
			File scr = new File("D:\\Avekshaa\\Rahul_Desale\\Automation\\TestData.xlsx");
			FileInputStream fis = new FileInputStream(scr);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet1=wb.getSheetAt(0);
			String data0=sheet1.getRow(0).getCell(0).getStringCellValue();
			System.out.println("Data From Excel is "+data0);
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			//driver.get("https://www.indiabulls.com/");
			driver.get("https://www.wikipedia.org/");
			Utility.captureScreenshot(driver, "Wiki");
			login();
			}
	public void login(){
		WebElement link;
		link = driver.findElement(By.id("searchInput"));
		//link = driver.findElement(By.xpath("//a[@id='hp-pl-knowmore']"));
		link.sendKeys("Java");
		link = driver.findElement(By.xpath("//i[@class='sprite svg-search-icon']"));
		link.click();
			try {
				Thread.sleep(4000);
				jse = (JavascriptExecutor)driver;
				jse.executeScript("scroll(0, 800)");
				Thread.sleep(4000);
				Utility.captureScreenshot(driver, "Java");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			driver.quit();
		} 
	public static void main(String[] args) throws IOException {
		Day4 myObj = new Day4();
		myObj.invokBrowser();
	}
}
